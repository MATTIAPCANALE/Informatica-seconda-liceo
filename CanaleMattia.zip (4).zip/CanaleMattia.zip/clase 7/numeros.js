let x = parseFloat( prompt("ingrese x"))  ;
let y = parseFloat( prompt("ingrese y"))  ;
if (y==0) {
    alert("no es posible calcular la división y el módulo.")
alert(`La suma es: ${x+y}`);
alert(`La resta es: ${x-y}`);
alert(`La multiplicación es: ${x*y}`);
alert(`La división no se puede hacer`);
alert(`El módulo no se puede`);
}
else {
alert(`La suma es: ${x+y}`);
alert(`La resta es: ${x-y}`);
alert(`La multiplicación es: ${x*y}`);
alert(`La división es: ${x/y}`);
alert(`El módulo es: ${x%y}`);}


